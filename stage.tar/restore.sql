--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.25
-- Dumped by pg_dump version 9.5.25

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX public.widget_backends_widget_id_service_name_method;
DROP INDEX public.user_apps_username_mode_tenant;
DROP INDEX public.blueprint_user_data_blueprint_id_username;
ALTER TABLE ONLY public."WidgetBackends" DROP CONSTRAINT "WidgetBackends_pkey";
ALTER TABLE ONLY public."UserApps" DROP CONSTRAINT "UserApps_pkey";
ALTER TABLE ONLY public."SequelizeMeta" DROP CONSTRAINT "SequelizeMeta_pkey";
ALTER TABLE ONLY public."BlueprintUserData" DROP CONSTRAINT "BlueprintUserData_pkey";
ALTER TABLE public."WidgetBackends" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."UserApps" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public."BlueprintUserData" ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public."WidgetBackends_id_seq";
DROP TABLE public."WidgetBackends";
DROP SEQUENCE public."UserApps_id_seq";
DROP TABLE public."UserApps";
DROP TABLE public."SequelizeMeta";
DROP SEQUENCE public."BlueprintUserData_id_seq";
DROP TABLE public."BlueprintUserData";
DROP TYPE public."enum_UserApps_mode";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: enum_UserApps_mode; Type: TYPE; Schema: public; Owner: cloudify
--

CREATE TYPE public."enum_UserApps_mode" AS ENUM (
    'customer',
    'main',
    'community'
);


ALTER TYPE public."enum_UserApps_mode" OWNER TO cloudify;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: BlueprintUserData; Type: TABLE; Schema: public; Owner: cloudify
--

CREATE TABLE public."BlueprintUserData" (
    id integer NOT NULL,
    "blueprintId" character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    layout json NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."BlueprintUserData" OWNER TO cloudify;

--
-- Name: BlueprintUserData_id_seq; Type: SEQUENCE; Schema: public; Owner: cloudify
--

CREATE SEQUENCE public."BlueprintUserData_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BlueprintUserData_id_seq" OWNER TO cloudify;

--
-- Name: BlueprintUserData_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cloudify
--

ALTER SEQUENCE public."BlueprintUserData_id_seq" OWNED BY public."BlueprintUserData".id;


--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: cloudify
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO cloudify;

--
-- Name: UserApps; Type: TABLE; Schema: public; Owner: cloudify
--

CREATE TABLE public."UserApps" (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    "appDataVersion" integer NOT NULL,
    mode public."enum_UserApps_mode" DEFAULT 'main'::public."enum_UserApps_mode" NOT NULL,
    "appData" json NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    tenant character varying(255) DEFAULT 'default_tenant'::character varying NOT NULL
);


ALTER TABLE public."UserApps" OWNER TO cloudify;

--
-- Name: UserApps_id_seq; Type: SEQUENCE; Schema: public; Owner: cloudify
--

CREATE SEQUENCE public."UserApps_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UserApps_id_seq" OWNER TO cloudify;

--
-- Name: UserApps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cloudify
--

ALTER SEQUENCE public."UserApps_id_seq" OWNED BY public."UserApps".id;


--
-- Name: WidgetBackends; Type: TABLE; Schema: public; Owner: cloudify
--

CREATE TABLE public."WidgetBackends" (
    id integer NOT NULL,
    "widgetId" character varying(255) NOT NULL,
    "serviceName" character varying(255) NOT NULL,
    method character varying(255) NOT NULL,
    script jsonb,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."WidgetBackends" OWNER TO cloudify;

--
-- Name: WidgetBackends_id_seq; Type: SEQUENCE; Schema: public; Owner: cloudify
--

CREATE SEQUENCE public."WidgetBackends_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."WidgetBackends_id_seq" OWNER TO cloudify;

--
-- Name: WidgetBackends_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cloudify
--

ALTER SEQUENCE public."WidgetBackends_id_seq" OWNED BY public."WidgetBackends".id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cloudify
--

ALTER TABLE ONLY public."BlueprintUserData" ALTER COLUMN id SET DEFAULT nextval('public."BlueprintUserData_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cloudify
--

ALTER TABLE ONLY public."UserApps" ALTER COLUMN id SET DEFAULT nextval('public."UserApps_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cloudify
--

ALTER TABLE ONLY public."WidgetBackends" ALTER COLUMN id SET DEFAULT nextval('public."WidgetBackends_id_seq"'::regclass);


--
-- Data for Name: BlueprintUserData; Type: TABLE DATA; Schema: public; Owner: cloudify
--

COPY public."BlueprintUserData" (id, "blueprintId", username, layout, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."BlueprintUserData" (id, "blueprintId", username, layout, "createdAt", "updatedAt") FROM '$$PATH$$/2212.dat';

--
-- Name: BlueprintUserData_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cloudify
--

SELECT pg_catalog.setval('public."BlueprintUserData_id_seq"', 1, false);


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: cloudify
--

COPY public."SequelizeMeta" (name) FROM stdin;
\.
COPY public."SequelizeMeta" (name) FROM '$$PATH$$/2206.dat';

--
-- Data for Name: UserApps; Type: TABLE DATA; Schema: public; Owner: cloudify
--

COPY public."UserApps" (id, username, "appDataVersion", mode, "appData", "createdAt", "updatedAt", tenant) FROM stdin;
\.
COPY public."UserApps" (id, username, "appDataVersion", mode, "appData", "createdAt", "updatedAt", tenant) FROM '$$PATH$$/2208.dat';

--
-- Name: UserApps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cloudify
--

SELECT pg_catalog.setval('public."UserApps_id_seq"', 1, true);


--
-- Data for Name: WidgetBackends; Type: TABLE DATA; Schema: public; Owner: cloudify
--

COPY public."WidgetBackends" (id, "widgetId", "serviceName", method, script, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."WidgetBackends" (id, "widgetId", "serviceName", method, script, "createdAt", "updatedAt") FROM '$$PATH$$/2210.dat';

--
-- Name: WidgetBackends_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cloudify
--

SELECT pg_catalog.setval('public."WidgetBackends_id_seq"', 3, true);


--
-- Name: BlueprintUserData_pkey; Type: CONSTRAINT; Schema: public; Owner: cloudify
--

ALTER TABLE ONLY public."BlueprintUserData"
    ADD CONSTRAINT "BlueprintUserData_pkey" PRIMARY KEY (id);


--
-- Name: SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: cloudify
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: UserApps_pkey; Type: CONSTRAINT; Schema: public; Owner: cloudify
--

ALTER TABLE ONLY public."UserApps"
    ADD CONSTRAINT "UserApps_pkey" PRIMARY KEY (id);


--
-- Name: WidgetBackends_pkey; Type: CONSTRAINT; Schema: public; Owner: cloudify
--

ALTER TABLE ONLY public."WidgetBackends"
    ADD CONSTRAINT "WidgetBackends_pkey" PRIMARY KEY (id);


--
-- Name: blueprint_user_data_blueprint_id_username; Type: INDEX; Schema: public; Owner: cloudify
--

CREATE UNIQUE INDEX blueprint_user_data_blueprint_id_username ON public."BlueprintUserData" USING btree ("blueprintId", username);


--
-- Name: user_apps_username_mode_tenant; Type: INDEX; Schema: public; Owner: cloudify
--

CREATE UNIQUE INDEX user_apps_username_mode_tenant ON public."UserApps" USING btree (username, mode, tenant);


--
-- Name: widget_backends_widget_id_service_name_method; Type: INDEX; Schema: public; Owner: cloudify
--

CREATE UNIQUE INDEX widget_backends_widget_id_service_name_method ON public."WidgetBackends" USING btree ("widgetId", "serviceName", method);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

